[Produce 101 Season 2 Rankings](https://p101s2.github.io/)

An interactive ranking chart for MNet's Produce 101 Season 2 made with d3.js. I began this project around Episode 4 in order to better keep track of the numerous contestants and also in hopes of being able to better predict the final 11 winners. I updated this website after each episode as the season progressed. This site now displays the full rankings and final results for each contestant.

![alt text](screenshot.png "Screenshot")
